import React, { useEffect, useState } from "react";
import PasswordBox from "../passwordBox/PasswordBox";
import SelectInput from "../selectedInput/SelectInput";
import "./signup.scss";

export default function Signup() {
  const [inputs, setInputs] = useState({});
  const [states, setStates] = useState([]);
  const [{ state, city }, setSateCity] = useState({
    state: "آذربایجان شرقی",
    city: "",
  });

  const handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setInputs((values) => ({ ...values, [name]: value }));
  };

  useEffect(() => {
    fetch("./iranstates.json")
      .then((res) => res.json())
      .then((response) => {
        // console.log(Object.entries(response));
        // console.log((Object.values(Object.entries(response)
        // .filter(([key, value]) => key === state)).at(0)[1]));
        setStates(response);
      });
  }, []);

  const stateOptions = Object.keys(states).map((state) => (
    <option key={state} value={state}>
      {state}
    </option>
  ));

  const cityOptions = () => {
    for (const [key, value] of Object.entries(states)) {
      if (key === state) {
        console.log(key);
        return value.map((item) => (
          <option key={item} value={item}>
            {item}
          </option>
        ));
      }
    }
  };

  // const cityOptions2 = (Object.values(Object.entries(states)
  // .filter(([key, value]) => key === state)).at(0)[1])
  //   .map((item) => (
  //     <option key={item} value={item}>
  //       {item}
  //     </option>
  //   ));

  function handleStateChange(event) {
    setSateCity((data) => ({ city: "", state: event.target.value }));
  }

  function handleCityChange(event) {
    setSateCity((data) => ({ ...data, city: event.target.value }));
    handleChange(event);
  }



  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(inputs);
  };

  return (
    <>
      <h2>رايگان ثبت نام كنيد</h2>
      <form className="form-signup" onSubmit={handleSubmit}>
        <div className="row">
          <input
            type="text"
            name="username"
            placeholder="نام "
            value={inputs.username || ""}
            onChange={handleChange}
          />
          <input
            type="text"
            name="lastname"
            placeholder="نام خانوادگي "
            value={inputs.lastname || ""}
            onChange={handleChange}
          />
        </div>

        <input
          type="text"
          name="email"
          placeholder="پست الكترونيك "
          value={inputs.email || ""}
          onChange={handleChange}
        />
        <PasswordBox className="pass-box"
          passwordName="password"
          passwordValue={inputs.password || ""}
          changeHandler={handleChange}
        />
        <div className="form-state row">
          <select value={state} onChange={handleStateChange}>
            {stateOptions}
          </select>
          <select
          className="form-state__state"
            name="city"
            value={inputs.city || ""}
            onChange={handleCityChange}
          >
            {cityOptions()}
          </select>
        </div>
        <div className="row">
          <select
            name="education"
            value={inputs.education || ""}
            onChange={handleCityChange}
          >
            <option value="" selected>تحصیلات</option>
            <option value="کارشناسی ارشد">کارشناسی ارشد</option>
            <option value="کارشناسی">کارشناسی</option>
            <option value="فوق دیپلم">فوق دیپلم</option>
            <option value="دیپلم">دیپلم</option>
          </select>
          {inputs.education !== "" ? <input
            type="text"
            name="educationPlace"
            placeholder="محل تحصیل"
            value={inputs.educationPlace || ""}
            onChange={handleChange}
          /> : <span></span>}
          
        </div>

        <input className="form-btn" type="submit" value="ثبت نام" />
      </form>
    </>
  );
}
