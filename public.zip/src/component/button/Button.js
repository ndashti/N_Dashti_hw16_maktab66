import React from 'react'

export default function 
({title}) {
  return (
    <>
        <button >{title}</button>
    </>
  )
}
