import './App.css';
import Parent from './component/Parent';
import ParentApp from './component1/ParentApp';
function App() {
  return (
    <div className="App">
        {/* <ParentApp /> */}
        <Parent />
    </div>
  );
}

export default App;
